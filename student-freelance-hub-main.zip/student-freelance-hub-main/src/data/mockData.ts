export interface Project {
  id: string;
  title: string;
  description: string;
  budget: number;
  deadline: string;
  skills: string[];
  category: string;
  clientName: string;
  clientId: string;
  status: 'open' | 'in_progress' | 'completed';
  bids: Bid[];
  createdAt: string;
}

export interface Bid {
  id: string;
  projectId: string;
  studentId: string;
  studentName: string;
  amount: number;
  message: string;
  status: 'pending' | 'accepted' | 'rejected';
  createdAt: string;
}

export interface Message {
  id: string;
  senderId: string;
  senderName: string;
  text: string;
  timestamp: string;
}

export interface Review {
  id: string;
  fromId: string;
  fromName: string;
  toId: string;
  rating: number;
  comment: string;
  createdAt: string;
}

export const mockProjects: Project[] = [
  {
    id: '1', title: 'E-Commerce Mobile App Design', description: 'Looking for a talented designer to create a modern e-commerce mobile app with a focus on user experience and clean aesthetics.', budget: 500, deadline: '2026-05-01', skills: ['UI/UX', 'Figma', 'Mobile Design'], category: 'Design', clientName: 'TechCorp Inc.', clientId: 'c1', status: 'open', bids: [
      { id: 'b1', projectId: '1', studentId: '1', studentName: 'Alex Chen', amount: 450, message: 'I have extensive experience in mobile app design. Check out my portfolio!', status: 'pending', createdAt: '2026-04-02' },
    ], createdAt: '2026-04-01',
  },
  {
    id: '2', title: 'Machine Learning Data Pipeline', description: 'Build an ML data pipeline for processing customer analytics data. Must include data cleaning, feature engineering, and model training.', budget: 800, deadline: '2026-05-15', skills: ['Python', 'ML', 'Data Science'], category: 'Data Science', clientName: 'DataDriven Co.', clientId: 'c2', status: 'open', bids: [], createdAt: '2026-04-02',
  },
  {
    id: '3', title: 'Portfolio Website Development', description: 'Need a responsive portfolio website built with React and modern animations. Must be SEO-friendly and fast.', budget: 350, deadline: '2026-04-25', skills: ['React', 'TypeScript', 'Tailwind'], category: 'Web Development', clientName: 'Creative Studio', clientId: 'c3', status: 'in_progress', bids: [
      { id: 'b2', projectId: '3', studentId: '2', studentName: 'Maya Patel', amount: 320, message: 'React is my specialty. I can deliver this in 2 weeks.', status: 'accepted', createdAt: '2026-04-01' },
    ], createdAt: '2026-03-28',
  },
  {
    id: '4', title: 'Social Media Dashboard', description: 'Create a comprehensive social media analytics dashboard with real-time data visualization and reporting features.', budget: 650, deadline: '2026-06-01', skills: ['React', 'Node.js', 'Charts'], category: 'Web Development', clientName: 'MarketPro', clientId: 'c4', status: 'open', bids: [], createdAt: '2026-04-03',
  },
  {
    id: '5', title: 'Brand Identity Design', description: 'Complete brand identity package including logo, color palette, typography, and brand guidelines document.', budget: 400, deadline: '2026-05-10', skills: ['Branding', 'Illustrator', 'Photoshop'], category: 'Design', clientName: 'StartupXYZ', clientId: 'c5', status: 'open', bids: [
      { id: 'b3', projectId: '5', studentId: '1', studentName: 'Alex Chen', amount: 380, message: 'I specialize in brand identity design with 20+ projects completed.', status: 'pending', createdAt: '2026-04-03' },
    ], createdAt: '2026-04-02',
  },
];

export const mockMessages: Record<string, Message[]> = {
  'conv1': [
    { id: 'm1', senderId: 'c1', senderName: 'TechCorp', text: 'Hi Alex! I saw your bid on the mobile app project.', timestamp: '2026-04-02T10:00:00' },
    { id: 'm2', senderId: '1', senderName: 'Alex', text: 'Hi! Yes, I am very interested. I have relevant experience.', timestamp: '2026-04-02T10:05:00' },
    { id: 'm3', senderId: 'c1', senderName: 'TechCorp', text: 'Great! Can you share some of your previous work?', timestamp: '2026-04-02T10:10:00' },
    { id: 'm4', senderId: '1', senderName: 'Alex', text: 'Absolutely! Here is my portfolio link. I have designed 5 mobile apps in the past year.', timestamp: '2026-04-02T10:15:00' },
  ],
};

export const mockNotifications = [
  { id: 'n1', text: 'New project posted: Social Media Dashboard', time: '2 hours ago', read: false },
  { id: 'n2', text: 'Your bid on E-Commerce App was viewed', time: '5 hours ago', read: false },
  { id: 'n3', text: 'Payment released for Portfolio Website', time: '1 day ago', read: true },
  { id: 'n4', text: 'New message from TechCorp Inc.', time: '1 day ago', read: true },
];

export const skillOptions = ['React', 'Node.js', 'TypeScript', 'Python', 'UI/UX', 'Figma', 'Machine Learning', 'Data Science', 'Mobile Design', 'Branding', 'Illustrator', 'Tailwind', 'Charts', 'Photoshop'];

export const categoryOptions = ['Web Development', 'Design', 'Data Science', 'Mobile Development', 'Marketing', 'Writing'];
