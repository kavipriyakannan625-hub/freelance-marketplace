import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Bell, LogOut, Menu, X, Briefcase } from 'lucide-react';
import { useState } from 'react';
import { mockNotifications } from '@/data/mockData';

const Navbar = () => {
  const { user, logout, isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const unread = mockNotifications.filter(n => !n.read).length;

  const handleLogout = () => { logout(); navigate('/'); };

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 glass-card border-b border-border/50">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg gradient-pink flex items-center justify-center">
            <Briefcase size={18} className="text-primary-foreground" />
          </div>
          <span className="font-display text-lg font-bold text-foreground">CampusGig</span>
        </Link>

        {isAuthenticated ? (
          <>
            <div className="hidden md:flex items-center gap-6">
              <Link to="/dashboard" className="text-sm text-muted-foreground hover:text-foreground transition-colors">Dashboard</Link>
              <Link to="/projects" className="text-sm text-muted-foreground hover:text-foreground transition-colors">Projects</Link>
              <Link to="/messages" className="text-sm text-muted-foreground hover:text-foreground transition-colors">Messages</Link>
              {user?.role === 'student' && <Link to="/profile" className="text-sm text-muted-foreground hover:text-foreground transition-colors">Profile</Link>}
            </div>
            <div className="flex items-center gap-3">
              <div className="relative">
                <button onClick={() => setNotifOpen(!notifOpen)} className="relative p-2 rounded-lg hover:bg-secondary transition-colors">
                  <Bell size={18} className="text-muted-foreground" />
                  {unread > 0 && <span className="absolute -top-0.5 -right-0.5 w-4 h-4 rounded-full gradient-pink text-[10px] flex items-center justify-center text-primary-foreground font-bold">{unread}</span>}
                </button>
                {notifOpen && (
                  <div className="absolute right-0 top-12 w-80 glass-card border border-border rounded-xl p-3 space-y-2 animate-fade-up">
                    <p className="text-xs font-semibold text-muted-foreground px-2 pb-1">Notifications</p>
                    {mockNotifications.map(n => (
                      <div key={n.id} className={`p-2.5 rounded-lg text-xs ${n.read ? 'text-muted-foreground' : 'text-foreground bg-secondary/50'}`}>
                        <p>{n.text}</p>
                        <p className="text-muted-foreground mt-1">{n.time}</p>
                      </div>
                    ))}
                  </div>
                )}
              </div>
              <div className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-secondary">
                <div className="w-6 h-6 rounded-full gradient-pink flex items-center justify-center text-[10px] text-primary-foreground font-bold">{user?.name?.[0]}</div>
                <span className="text-xs text-foreground">{user?.name}</span>
              </div>
              <button onClick={handleLogout} className="p-2 rounded-lg hover:bg-secondary transition-colors">
                <LogOut size={16} className="text-muted-foreground" />
              </button>
              <button onClick={() => setMobileOpen(!mobileOpen)} className="md:hidden p-2">
                {mobileOpen ? <X size={20} /> : <Menu size={20} />}
              </button>
            </div>
          </>
        ) : (
          <div className="flex items-center gap-3">
            <Link to="/login" className="text-sm text-muted-foreground hover:text-foreground transition-colors">Login</Link>
            <Link to="/register" className="text-sm px-4 py-2 rounded-lg gradient-pink text-primary-foreground font-medium hover:opacity-90 transition-opacity">Sign Up</Link>
          </div>
        )}
      </div>
      {mobileOpen && isAuthenticated && (
        <div className="md:hidden glass-card border-t border-border p-4 space-y-3 animate-fade-up">
          <Link to="/dashboard" onClick={() => setMobileOpen(false)} className="block text-sm text-muted-foreground">Dashboard</Link>
          <Link to="/projects" onClick={() => setMobileOpen(false)} className="block text-sm text-muted-foreground">Projects</Link>
          <Link to="/messages" onClick={() => setMobileOpen(false)} className="block text-sm text-muted-foreground">Messages</Link>
          {user?.role === 'student' && <Link to="/profile" onClick={() => setMobileOpen(false)} className="block text-sm text-muted-foreground">Profile</Link>}
        </div>
      )}
    </nav>
  );
};

export default Navbar;
