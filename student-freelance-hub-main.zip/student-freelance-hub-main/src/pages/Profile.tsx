import { useAuth } from '@/contexts/AuthContext';
import { useState } from 'react';
import { Star, ExternalLink, Edit3, Save, Plus } from 'lucide-react';

const Profile = () => {
  const { user } = useAuth();
  const [editing, setEditing] = useState(false);
  const [bio, setBio] = useState(user?.bio || 'Passionate developer and designer.');
  const [skills, setSkills] = useState(user?.skills || ['React', 'Node.js', 'TypeScript']);
  const [newSkill, setNewSkill] = useState('');

  const portfolio = [
    { title: 'E-Commerce Dashboard', link: '#', type: 'Web App' },
    { title: 'Brand Identity - Acme Co', link: '#', type: 'Design' },
    { title: 'Weather App', link: '#', type: 'Mobile' },
  ];

  const reviews = [
    { name: 'TechCorp Inc.', rating: 5, comment: 'Outstanding work! Delivered before deadline.' },
    { name: 'Creative Studio', rating: 4, comment: 'Great design sense and communication.' },
    { name: 'StartupXYZ', rating: 5, comment: 'Will definitely hire again!' },
  ];

  const addSkill = () => {
    if (newSkill.trim() && !skills.includes(newSkill.trim())) {
      setSkills([...skills, newSkill.trim()]);
      setNewSkill('');
    }
  };

  return (
    <div className="min-h-screen pt-20 px-4 pb-10">
      <div className="container mx-auto max-w-4xl">
        {/* Header */}
        <div className="glass-card p-8 mb-6 animate-fade-up">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-5">
              <div className="w-20 h-20 rounded-2xl gradient-pink flex items-center justify-center text-3xl text-primary-foreground font-bold">{user?.name?.[0]}</div>
              <div>
                <h1 className="font-display text-2xl font-bold">{user?.name}</h1>
                <p className="text-sm text-muted-foreground">{user?.email}</p>
                {user?.collegeId && <p className="text-xs text-primary mt-1">ID: {user.collegeId}</p>}
                <div className="flex items-center gap-1 mt-2">
                  {Array(5).fill(0).map((_, i) => <Star key={i} size={12} className={i < 4 ? "text-primary fill-primary" : "text-muted-foreground"} />)}
                  <span className="text-xs text-muted-foreground ml-1">4.8 (12 reviews)</span>
                </div>
              </div>
            </div>
            <button onClick={() => setEditing(!editing)} className="p-2 rounded-lg hover:bg-secondary transition-colors text-muted-foreground">
              {editing ? <Save size={18} /> : <Edit3 size={18} />}
            </button>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {/* Bio & Skills */}
          <div className="space-y-6">
            <div className="glass-card p-6 animate-fade-up">
              <h2 className="font-sans font-semibold text-foreground mb-3">About</h2>
              {editing ? (
                <textarea value={bio} onChange={e => setBio(e.target.value)} rows={3} className="w-full bg-secondary border border-border rounded-lg px-4 py-2.5 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary resize-none" />
              ) : (
                <p className="text-sm text-muted-foreground leading-relaxed">{bio}</p>
              )}
            </div>

            <div className="glass-card p-6 animate-fade-up">
              <h2 className="font-sans font-semibold text-foreground mb-3">Skills</h2>
              <div className="flex flex-wrap gap-2 mb-3">
                {skills.map(s => <span key={s} className="text-xs px-3 py-1.5 rounded-full bg-primary/20 text-primary">{s}</span>)}
              </div>
              {editing && (
                <div className="flex gap-2">
                  <input value={newSkill} onChange={e => setNewSkill(e.target.value)} onKeyDown={e => e.key === 'Enter' && addSkill()} placeholder="Add skill" className="flex-1 bg-secondary border border-border rounded-lg px-3 py-2 text-xs text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary" />
                  <button onClick={addSkill} className="p-2 rounded-lg gradient-pink text-primary-foreground"><Plus size={14} /></button>
                </div>
              )}
            </div>
          </div>

          {/* Portfolio & Reviews */}
          <div className="space-y-6">
            <div className="glass-card p-6 animate-fade-up">
              <h2 className="font-sans font-semibold text-foreground mb-3">Portfolio</h2>
              <div className="space-y-3">
                {portfolio.map(p => (
                  <div key={p.title} className="flex items-center justify-between p-3 rounded-xl bg-secondary/50 hover:bg-secondary transition-colors">
                    <div>
                      <p className="text-sm font-medium text-foreground">{p.title}</p>
                      <p className="text-[10px] text-muted-foreground">{p.type}</p>
                    </div>
                    <ExternalLink size={14} className="text-muted-foreground" />
                  </div>
                ))}
                {editing && (
                  <button className="w-full py-2.5 rounded-xl border border-dashed border-border text-xs text-muted-foreground hover:text-foreground hover:border-primary transition-colors flex items-center justify-center gap-1">
                    <Plus size={14} /> Add Project
                  </button>
                )}
              </div>
            </div>

            <div className="glass-card p-6 animate-fade-up">
              <h2 className="font-sans font-semibold text-foreground mb-3">Reviews</h2>
              <div className="space-y-3">
                {reviews.map((r, i) => (
                  <div key={i} className="p-3 rounded-xl bg-secondary/50">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-sm font-medium text-foreground">{r.name}</span>
                      <div className="flex">{Array(r.rating).fill(0).map((_, j) => <Star key={j} size={10} className="text-primary fill-primary" />)}</div>
                    </div>
                    <p className="text-xs text-muted-foreground">{r.comment}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;
