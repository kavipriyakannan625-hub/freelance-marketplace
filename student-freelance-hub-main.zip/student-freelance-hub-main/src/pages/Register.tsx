import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth, UserRole } from '@/contexts/AuthContext';
import { Briefcase, GraduationCap, Building2, Eye, EyeOff } from 'lucide-react';

const Register = () => {
  const [role, setRole] = useState<UserRole>('student');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [collegeId, setCollegeId] = useState('');
  const [company, setCompany] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [error, setError] = useState('');
  const { register } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!name || !email || !password) { setError('All fields are required.'); return; }
    if (password.length < 6) { setError('Password must be at least 6 characters.'); return; }
    if (role === 'student' && !/^COL\d{5}$/.test(collegeId)) { setError('College ID must be in format COL12345.'); return; }
    if (role === 'client' && !company) { setError('Company name is required.'); return; }
    register({ name, email, password, role, collegeId: role === 'student' ? collegeId : undefined, company: role === 'client' ? company : undefined });
    navigate('/dashboard');
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4 py-20 relative">
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute bottom-1/3 right-1/3 w-80 h-80 rounded-full bg-accent/10 blur-[120px]" />
      </div>
      <div className="w-full max-w-md relative z-10 animate-fade-up">
        <div className="text-center mb-8">
          <div className="w-12 h-12 rounded-xl gradient-pink flex items-center justify-center mx-auto mb-4">
            <Briefcase size={22} className="text-primary-foreground" />
          </div>
          <h1 className="font-display text-2xl font-bold">Create Account</h1>
          <p className="text-sm text-muted-foreground mt-1">Join CampusGig and start your journey</p>
        </div>

        <div className="flex gap-2 mb-6">
          {[{ r: 'student' as UserRole, icon: GraduationCap, label: 'Student' }, { r: 'client' as UserRole, icon: Building2, label: 'Client' }].map(({ r, icon: Icon, label }) => (
            <button key={r} onClick={() => setRole(r)} className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl text-sm font-medium transition-all ${role === r ? 'gradient-pink text-primary-foreground glow-pink' : 'bg-secondary text-muted-foreground hover:text-foreground'}`}>
              <Icon size={16} /> {label}
            </button>
          ))}
        </div>

        <form onSubmit={handleSubmit} className="glass-card p-6 space-y-4">
          <div>
            <label className="text-xs text-muted-foreground mb-1.5 block">Full Name</label>
            <input value={name} onChange={e => setName(e.target.value)} placeholder="John Doe" className="w-full bg-secondary border border-border rounded-lg px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary" />
          </div>
          {role === 'student' && (
            <div>
              <label className="text-xs text-muted-foreground mb-1.5 block">College ID</label>
              <input value={collegeId} onChange={e => setCollegeId(e.target.value)} placeholder="COL12345" className="w-full bg-secondary border border-border rounded-lg px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary" />
            </div>
          )}
          {role === 'client' && (
            <div>
              <label className="text-xs text-muted-foreground mb-1.5 block">Company / Organization</label>
              <input value={company} onChange={e => setCompany(e.target.value)} placeholder="TechCorp Inc." className="w-full bg-secondary border border-border rounded-lg px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary" />
            </div>
          )}
          <div>
            <label className="text-xs text-muted-foreground mb-1.5 block">Email</label>
            <input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="you@email.com" className="w-full bg-secondary border border-border rounded-lg px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary" />
          </div>
          <div>
            <label className="text-xs text-muted-foreground mb-1.5 block">Password</label>
            <div className="relative">
              <input type={showPw ? 'text' : 'password'} value={password} onChange={e => setPassword(e.target.value)} placeholder="Min 6 characters" className="w-full bg-secondary border border-border rounded-lg px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary pr-10" />
              <button type="button" onClick={() => setShowPw(!showPw)} className="absolute right-3 top-2.5 text-muted-foreground">
                {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>
          </div>
          {error && <p className="text-xs text-destructive">{error}</p>}
          <button type="submit" className="w-full py-3 rounded-xl gradient-pink text-primary-foreground font-semibold text-sm hover:opacity-90 transition-opacity">Create Account</button>
        </form>
        <p className="text-center text-sm text-muted-foreground mt-6">Already have an account? <Link to="/login" className="text-primary hover:underline">Sign in</Link></p>
      </div>
    </div>
  );
};

export default Register;
