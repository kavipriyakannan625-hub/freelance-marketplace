import { Link } from 'react-router-dom';
import { ArrowRight, Zap, Shield, Users, TrendingUp } from 'lucide-react';

const Landing = () => {
  const features = [
    { icon: Zap, title: 'Fast Matching', desc: 'Get matched with the perfect freelancer or project in seconds.' },
    { icon: Shield, title: 'Verified Students', desc: 'All freelancers are verified college students with valid IDs.' },
    { icon: Users, title: 'Real-Time Chat', desc: 'Communicate seamlessly with built-in messaging.' },
    { icon: TrendingUp, title: 'Build Portfolio', desc: 'Students build their portfolio while earning.' },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Hero */}
      <section className="relative pt-32 pb-20 px-4 overflow-hidden">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full bg-primary/10 blur-[120px]" />
          <div className="absolute bottom-1/4 right-1/4 w-80 h-80 rounded-full bg-accent/10 blur-[100px]" />
        </div>
        <div className="container mx-auto text-center relative z-10">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-border bg-secondary/50 mb-8 animate-fade-up">
            <span className="w-2 h-2 rounded-full gradient-pink" />
            <span className="text-xs text-muted-foreground">The #1 Freelance Platform for Students</span>
          </div>
          <h1 className="font-display text-5xl md:text-7xl font-bold leading-tight mb-6 animate-fade-up">
            Where <span className="gradient-text">Talent</span> Meets
            <br />Opportunity
          </h1>
          <p className="text-lg text-muted-foreground max-w-xl mx-auto mb-10 animate-fade-up">
            Connect college students with real-world projects. Build your career, one gig at a time.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center animate-fade-up">
            <Link to="/register" className="inline-flex items-center justify-center gap-2 px-8 py-3.5 rounded-xl gradient-pink text-primary-foreground font-semibold text-sm hover:opacity-90 transition-opacity glow-pink">
              Get Started <ArrowRight size={16} />
            </Link>
            <Link to="/projects" className="inline-flex items-center justify-center gap-2 px-8 py-3.5 rounded-xl border border-border text-foreground font-semibold text-sm hover:bg-secondary transition-colors">
              Browse Projects
            </Link>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-8 max-w-lg mx-auto mt-20">
            {[['2,500+', 'Students'], ['1,200+', 'Projects'], ['$450K+', 'Earned']].map(([val, label]) => (
              <div key={label} className="text-center">
                <p className="text-2xl font-bold gradient-text">{val}</p>
                <p className="text-xs text-muted-foreground mt-1">{label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20 px-4">
        <div className="container mx-auto">
          <h2 className="font-display text-3xl md:text-4xl font-bold text-center mb-4">Why <span className="gradient-text">CampusGig</span>?</h2>
          <p className="text-muted-foreground text-center max-w-md mx-auto mb-14">Everything you need to launch your freelancing career while still in college.</p>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map(({ icon: Icon, title, desc }) => (
              <div key={title} className="glass-card p-6 hover-glow group cursor-default">
                <div className="w-10 h-10 rounded-xl gradient-pink flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                  <Icon size={20} className="text-primary-foreground" />
                </div>
                <h3 className="font-sans font-semibold text-foreground mb-2">{title}</h3>
                <p className="text-sm text-muted-foreground">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 px-4">
        <div className="container mx-auto">
          <div className="glass-card p-12 md:p-16 text-center glow-pink relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-primary/5 to-accent/5" />
            <div className="relative z-10">
              <h2 className="font-display text-3xl md:text-4xl font-bold mb-4">Ready to Start?</h2>
              <p className="text-muted-foreground mb-8 max-w-md mx-auto">Join thousands of college students already earning through CampusGig.</p>
              <Link to="/register" className="inline-flex items-center gap-2 px-8 py-3.5 rounded-xl gradient-pink text-primary-foreground font-semibold text-sm hover:opacity-90 transition-opacity">
                Create Free Account <ArrowRight size={16} />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-10 px-4">
        <div className="container mx-auto flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-sm text-muted-foreground">© 2026 CampusGig. All rights reserved.</p>
          <div className="flex gap-6 text-sm text-muted-foreground">
            <span className="hover:text-foreground cursor-pointer transition-colors">Privacy</span>
            <span className="hover:text-foreground cursor-pointer transition-colors">Terms</span>
            <span className="hover:text-foreground cursor-pointer transition-colors">Contact</span>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Landing;
