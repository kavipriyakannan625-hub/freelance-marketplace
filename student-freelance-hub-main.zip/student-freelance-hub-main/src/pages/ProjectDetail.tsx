import { useParams } from 'react-router-dom';
import { mockProjects } from '@/data/mockData';
import { useAuth } from '@/contexts/AuthContext';
import { useState } from 'react';
import { Clock, DollarSign, User, Star, Send, CheckCircle, XCircle } from 'lucide-react';

const ProjectDetail = () => {
  const { id } = useParams();
  const { user } = useAuth();
  const project = mockProjects.find(p => p.id === id);
  const [bidAmount, setBidAmount] = useState('');
  const [bidMessage, setBidMessage] = useState('');
  const [bidSubmitted, setBidSubmitted] = useState(false);
  const isStudent = user?.role === 'student';

  if (!project) return <div className="min-h-screen pt-20 flex items-center justify-center text-muted-foreground">Project not found</div>;

  const handleBid = (e: React.FormEvent) => {
    e.preventDefault();
    setBidSubmitted(true);
  };

  return (
    <div className="min-h-screen pt-20 px-4 pb-10">
      <div className="container mx-auto max-w-4xl">
        <div className="glass-card p-8 mb-6 animate-fade-up">
          <div className="flex items-start justify-between mb-4">
            <div>
              <span className={`text-[10px] px-2.5 py-0.5 rounded-full mb-2 inline-block ${project.status === 'open' ? 'bg-primary/20 text-primary' : project.status === 'in_progress' ? 'bg-yellow-500/20 text-yellow-400' : 'bg-green-500/20 text-green-400'}`}>{project.status.replace('_', ' ')}</span>
              <h1 className="font-display text-2xl md:text-3xl font-bold mt-1">{project.title}</h1>
              <p className="text-sm text-muted-foreground mt-1">by {project.clientName}</p>
            </div>
            <span className="text-2xl font-bold gradient-text">${project.budget}</span>
          </div>

          <p className="text-sm text-muted-foreground leading-relaxed mb-6">{project.description}</p>

          <div className="flex flex-wrap gap-4 mb-6 text-xs text-muted-foreground">
            <span className="flex items-center gap-1.5"><Clock size={14} /> Deadline: {project.deadline}</span>
            <span className="flex items-center gap-1.5"><DollarSign size={14} /> Budget: ${project.budget}</span>
            <span className="flex items-center gap-1.5"><User size={14} /> {project.bids.length} bids</span>
          </div>

          <div className="flex flex-wrap gap-2">
            {project.skills.map(s => <span key={s} className="text-xs px-3 py-1 rounded-full bg-secondary text-muted-foreground">{s}</span>)}
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {/* Bids */}
          <div className="glass-card p-6 animate-fade-up">
            <h2 className="font-sans font-semibold text-foreground mb-4">Bids ({project.bids.length})</h2>
            {project.bids.length === 0 ? (
              <p className="text-sm text-muted-foreground">No bids yet. Be the first!</p>
            ) : (
              <div className="space-y-3">
                {project.bids.map(b => (
                  <div key={b.id} className="p-4 rounded-xl bg-secondary/50">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 rounded-full gradient-pink flex items-center justify-center text-[10px] text-primary-foreground font-bold">{b.studentName[0]}</div>
                        <span className="text-sm font-medium text-foreground">{b.studentName}</span>
                      </div>
                      <span className="text-sm font-bold gradient-text">${b.amount}</span>
                    </div>
                    <p className="text-xs text-muted-foreground mb-2">{b.message}</p>
                    <div className="flex items-center justify-between">
                      <span className={`text-[10px] px-2 py-0.5 rounded-full ${b.status === 'pending' ? 'bg-yellow-500/20 text-yellow-400' : b.status === 'accepted' ? 'bg-green-500/20 text-green-400' : 'bg-destructive/20 text-destructive'}`}>{b.status}</span>
                      {user?.role === 'client' && b.status === 'pending' && (
                        <div className="flex gap-2">
                          <button className="text-green-400 hover:text-green-300"><CheckCircle size={16} /></button>
                          <button className="text-destructive hover:opacity-80"><XCircle size={16} /></button>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Place Bid / Reviews */}
          <div className="space-y-6">
            {isStudent && project.status === 'open' && (
              <div className="glass-card p-6 animate-fade-up">
                <h2 className="font-sans font-semibold text-foreground mb-4">Place Your Bid</h2>
                {bidSubmitted ? (
                  <div className="text-center py-4">
                    <CheckCircle size={32} className="text-primary mx-auto mb-2" />
                    <p className="text-sm text-foreground font-medium">Bid submitted!</p>
                    <p className="text-xs text-muted-foreground mt-1">You'll be notified when reviewed.</p>
                  </div>
                ) : (
                  <form onSubmit={handleBid} className="space-y-3">
                    <input value={bidAmount} onChange={e => setBidAmount(e.target.value)} type="number" placeholder="Your bid amount ($)" className="w-full bg-secondary border border-border rounded-lg px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary" />
                    <textarea value={bidMessage} onChange={e => setBidMessage(e.target.value)} placeholder="Why are you a great fit?" rows={3} className="w-full bg-secondary border border-border rounded-lg px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary resize-none" />
                    <button type="submit" className="w-full py-2.5 rounded-xl gradient-pink text-primary-foreground font-semibold text-sm hover:opacity-90 transition-opacity flex items-center justify-center gap-2">
                      <Send size={14} /> Submit Bid
                    </button>
                  </form>
                )}
              </div>
            )}

            {/* Reviews */}
            <div className="glass-card p-6 animate-fade-up">
              <h2 className="font-sans font-semibold text-foreground mb-4">Reviews</h2>
              {[{ name: 'Sarah K.', rating: 5, comment: 'Excellent work, delivered on time!' }, { name: 'Mike R.', rating: 4, comment: 'Great communication and quality.' }].map((r, i) => (
                <div key={i} className="p-3 rounded-xl bg-secondary/50 mb-2">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-sm font-medium text-foreground">{r.name}</span>
                    <div className="flex">{Array(r.rating).fill(0).map((_, j) => <Star key={j} size={10} className="text-primary fill-primary" />)}</div>
                  </div>
                  <p className="text-xs text-muted-foreground">{r.comment}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProjectDetail;
