import { useState } from 'react';
import { mockMessages } from '@/data/mockData';
import { useAuth } from '@/contexts/AuthContext';
import { Send, Search } from 'lucide-react';

const conversations = [
  { id: 'conv1', name: 'TechCorp Inc.', lastMsg: 'Can you share some of your previous work?', time: '10:10 AM', unread: 1, avatar: 'T' },
  { id: 'conv2', name: 'Creative Studio', lastMsg: 'The project is almost done!', time: 'Yesterday', unread: 0, avatar: 'C' },
  { id: 'conv3', name: 'DataDriven Co.', lastMsg: 'Thanks for your interest.', time: '2 days ago', unread: 0, avatar: 'D' },
];

const Messages = () => {
  const { user } = useAuth();
  const [activeConv, setActiveConv] = useState('conv1');
  const [newMsg, setNewMsg] = useState('');
  const [msgs, setMsgs] = useState(mockMessages);

  const handleSend = () => {
    if (!newMsg.trim()) return;
    const msg = { id: Date.now().toString(), senderId: user?.id || '1', senderName: user?.name || 'You', text: newMsg, timestamp: new Date().toISOString() };
    setMsgs(prev => ({ ...prev, [activeConv]: [...(prev[activeConv] || []), msg] }));
    setNewMsg('');
  };

  const currentMsgs = msgs[activeConv] || [];

  return (
    <div className="min-h-screen pt-16">
      <div className="h-[calc(100vh-64px)] flex">
        {/* Sidebar */}
        <div className="w-80 border-r border-border flex flex-col shrink-0 hidden md:flex">
          <div className="p-4 border-b border-border">
            <h2 className="font-display text-lg font-bold mb-3">Messages</h2>
            <div className="relative">
              <Search size={14} className="absolute left-3 top-2.5 text-muted-foreground" />
              <input placeholder="Search conversations..." className="w-full bg-secondary border border-border rounded-lg pl-9 pr-4 py-2 text-xs text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary" />
            </div>
          </div>
          <div className="flex-1 overflow-y-auto">
            {conversations.map(c => (
              <button key={c.id} onClick={() => setActiveConv(c.id)} className={`w-full p-4 flex items-center gap-3 text-left hover:bg-secondary/50 transition-colors ${activeConv === c.id ? 'bg-secondary/50 border-l-2 border-primary' : ''}`}>
                <div className="w-10 h-10 rounded-full gradient-pink flex items-center justify-center text-sm text-primary-foreground font-bold shrink-0">{c.avatar}</div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-foreground">{c.name}</span>
                    <span className="text-[10px] text-muted-foreground">{c.time}</span>
                  </div>
                  <p className="text-xs text-muted-foreground truncate">{c.lastMsg}</p>
                </div>
                {c.unread > 0 && <span className="w-5 h-5 rounded-full gradient-pink flex items-center justify-center text-[10px] text-primary-foreground font-bold">{c.unread}</span>}
              </button>
            ))}
          </div>
        </div>

        {/* Chat */}
        <div className="flex-1 flex flex-col">
          <div className="p-4 border-b border-border flex items-center gap-3">
            <div className="w-8 h-8 rounded-full gradient-pink flex items-center justify-center text-sm text-primary-foreground font-bold">
              {conversations.find(c => c.id === activeConv)?.avatar}
            </div>
            <span className="font-medium text-sm text-foreground">{conversations.find(c => c.id === activeConv)?.name}</span>
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {currentMsgs.map(m => {
              const isMe = m.senderId === (user?.id || '1');
              return (
                <div key={m.id} className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[70%] px-4 py-2.5 rounded-2xl text-sm ${isMe ? 'gradient-pink text-primary-foreground rounded-br-md' : 'bg-secondary text-foreground rounded-bl-md'}`}>
                    <p>{m.text}</p>
                    <p className={`text-[10px] mt-1 ${isMe ? 'text-primary-foreground/70' : 'text-muted-foreground'}`}>
                      {new Date(m.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="p-4 border-t border-border">
            <div className="flex gap-2">
              <input value={newMsg} onChange={e => setNewMsg(e.target.value)} onKeyDown={e => e.key === 'Enter' && handleSend()} placeholder="Type a message..." className="flex-1 bg-secondary border border-border rounded-xl px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary" />
              <button onClick={handleSend} className="p-2.5 rounded-xl gradient-pink text-primary-foreground hover:opacity-90 transition-opacity">
                <Send size={16} />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Messages;
