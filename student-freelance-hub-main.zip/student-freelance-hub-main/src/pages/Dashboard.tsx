import { useAuth } from '@/contexts/AuthContext';
import { mockProjects, mockNotifications } from '@/data/mockData';
import { Briefcase, TrendingUp, DollarSign, Bell, ArrowRight, Clock } from 'lucide-react';
import { Link } from 'react-router-dom';

const Dashboard = () => {
  const { user } = useAuth();
  const isStudent = user?.role === 'student';

  const stats = isStudent
    ? [
        { icon: Briefcase, label: 'Active Bids', value: '3', color: 'from-primary to-accent' },
        { icon: TrendingUp, label: 'Projects Won', value: '7', color: 'from-primary to-accent' },
        { icon: DollarSign, label: 'Total Earned', value: '$2,450', color: 'from-primary to-accent' },
        { icon: Bell, label: 'Notifications', value: mockNotifications.filter(n => !n.read).length.toString(), color: 'from-primary to-accent' },
      ]
    : [
        { icon: Briefcase, label: 'Active Projects', value: '5', color: 'from-primary to-accent' },
        { icon: TrendingUp, label: 'Total Bids', value: '12', color: 'from-primary to-accent' },
        { icon: DollarSign, label: 'Total Spent', value: '$3,200', color: 'from-primary to-accent' },
        { icon: Bell, label: 'Notifications', value: mockNotifications.filter(n => !n.read).length.toString(), color: 'from-primary to-accent' },
      ];

  const recentProjects = mockProjects.slice(0, 3);

  return (
    <div className="min-h-screen pt-20 px-4 pb-10">
      <div className="container mx-auto max-w-6xl">
        <div className="mb-8 animate-fade-up">
          <h1 className="font-display text-3xl font-bold">Welcome back, <span className="gradient-text">{user?.name}</span></h1>
          <p className="text-sm text-muted-foreground mt-1">{isStudent ? 'Here\'s your freelancing overview' : 'Manage your projects and freelancers'}</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {stats.map(({ icon: Icon, label, value }, i) => (
            <div key={label} className="glass-card p-5 hover-glow animate-fade-up" style={{ animationDelay: `${i * 0.1}s` }}>
              <div className="flex items-center justify-between mb-3">
                <div className="w-9 h-9 rounded-lg gradient-pink flex items-center justify-center">
                  <Icon size={16} className="text-primary-foreground" />
                </div>
              </div>
              <p className="text-2xl font-bold text-foreground">{value}</p>
              <p className="text-xs text-muted-foreground mt-0.5">{label}</p>
            </div>
          ))}
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Recent Projects */}
          <div className="lg:col-span-2 glass-card p-6 animate-fade-up">
            <div className="flex items-center justify-between mb-5">
              <h2 className="font-sans font-semibold text-foreground">Recent Projects</h2>
              <Link to="/projects" className="text-xs text-primary flex items-center gap-1 hover:underline">View all <ArrowRight size={12} /></Link>
            </div>
            <div className="space-y-3">
              {recentProjects.map(p => (
                <Link to={`/projects/${p.id}`} key={p.id} className="block p-4 rounded-xl bg-secondary/50 hover:bg-secondary transition-colors group">
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="text-sm font-medium text-foreground group-hover:text-primary transition-colors">{p.title}</h3>
                      <p className="text-xs text-muted-foreground mt-1">{p.clientName}</p>
                    </div>
                    <span className="text-sm font-semibold gradient-text">${p.budget}</span>
                  </div>
                  <div className="flex items-center gap-3 mt-3">
                    <span className={`text-[10px] px-2 py-0.5 rounded-full ${p.status === 'open' ? 'bg-primary/20 text-primary' : p.status === 'in_progress' ? 'bg-yellow-500/20 text-yellow-400' : 'bg-green-500/20 text-green-400'}`}>{p.status.replace('_', ' ')}</span>
                    <span className="text-[10px] text-muted-foreground flex items-center gap-1"><Clock size={10} /> {p.deadline}</span>
                  </div>
                </Link>
              ))}
            </div>
          </div>

          {/* Notifications */}
          <div className="glass-card p-6 animate-fade-up">
            <h2 className="font-sans font-semibold text-foreground mb-5">Notifications</h2>
            <div className="space-y-3">
              {mockNotifications.map(n => (
                <div key={n.id} className={`p-3 rounded-xl text-xs ${n.read ? 'text-muted-foreground' : 'text-foreground bg-secondary/50'}`}>
                  <p>{n.text}</p>
                  <p className="text-muted-foreground mt-1">{n.time}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Payment Section */}
        <div className="glass-card p-6 mt-6 animate-fade-up">
          <h2 className="font-sans font-semibold text-foreground mb-5">Payment Status</h2>
          <div className="space-y-3">
            {[
              { project: 'Portfolio Website', amount: 320, status: 'Completed' },
              { project: 'E-Commerce App', amount: 450, status: 'In Progress' },
              { project: 'Brand Identity', amount: 380, status: 'Pending' },
            ].map(p => (
              <div key={p.project} className="flex items-center justify-between p-4 rounded-xl bg-secondary/50">
                <div>
                  <p className="text-sm font-medium text-foreground">{p.project}</p>
                  <p className="text-xs text-muted-foreground">${p.amount}</p>
                </div>
                <span className={`text-[10px] px-2.5 py-1 rounded-full font-medium ${p.status === 'Completed' ? 'bg-green-500/20 text-green-400' : p.status === 'In Progress' ? 'bg-yellow-500/20 text-yellow-400' : 'bg-primary/20 text-primary'}`}>{p.status}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
