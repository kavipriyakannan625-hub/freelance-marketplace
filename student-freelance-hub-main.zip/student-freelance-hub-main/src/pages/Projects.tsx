import { useState } from 'react';
import { mockProjects, skillOptions, categoryOptions } from '@/data/mockData';
import { useAuth } from '@/contexts/AuthContext';
import { Search, Filter, Clock, DollarSign, Plus, X } from 'lucide-react';
import { Link } from 'react-router-dom';

const Projects = () => {
  const { user } = useAuth();
  const [search, setSearch] = useState('');
  const [selectedSkill, setSelectedSkill] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [budgetRange, setBudgetRange] = useState('');
  const [showPost, setShowPost] = useState(false);
  const [newProject, setNewProject] = useState({ title: '', description: '', budget: '', deadline: '', skills: '' as string, category: '' });

  const filtered = mockProjects.filter(p => {
    if (search && !p.title.toLowerCase().includes(search.toLowerCase())) return false;
    if (selectedSkill && !p.skills.includes(selectedSkill)) return false;
    if (selectedCategory && p.category !== selectedCategory) return false;
    if (budgetRange === 'low' && p.budget > 300) return false;
    if (budgetRange === 'mid' && (p.budget < 300 || p.budget > 600)) return false;
    if (budgetRange === 'high' && p.budget < 600) return false;
    return true;
  });

  return (
    <div className="min-h-screen pt-20 px-4 pb-10">
      <div className="container mx-auto max-w-6xl">
        <div className="flex items-center justify-between mb-8 animate-fade-up">
          <div>
            <h1 className="font-display text-3xl font-bold">Browse <span className="gradient-text">Projects</span></h1>
            <p className="text-sm text-muted-foreground mt-1">Find your next opportunity</p>
          </div>
          {user?.role === 'client' && (
            <button onClick={() => setShowPost(true)} className="flex items-center gap-2 px-5 py-2.5 rounded-xl gradient-pink text-primary-foreground text-sm font-medium hover:opacity-90 transition-opacity">
              <Plus size={16} /> Post Project
            </button>
          )}
        </div>

        {/* Filters */}
        <div className="glass-card p-4 mb-6 animate-fade-up">
          <div className="flex flex-wrap gap-3">
            <div className="relative flex-1 min-w-[200px]">
              <Search size={14} className="absolute left-3 top-2.5 text-muted-foreground" />
              <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search projects..." className="w-full bg-secondary border border-border rounded-lg pl-9 pr-4 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary" />
            </div>
            <select value={selectedCategory} onChange={e => setSelectedCategory(e.target.value)} className="bg-secondary border border-border rounded-lg px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary">
              <option value="">All Categories</option>
              {categoryOptions.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
            <select value={selectedSkill} onChange={e => setSelectedSkill(e.target.value)} className="bg-secondary border border-border rounded-lg px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary">
              <option value="">All Skills</option>
              {skillOptions.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
            <select value={budgetRange} onChange={e => setBudgetRange(e.target.value)} className="bg-secondary border border-border rounded-lg px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary">
              <option value="">Any Budget</option>
              <option value="low">Under $300</option>
              <option value="mid">$300 - $600</option>
              <option value="high">$600+</option>
            </select>
          </div>
        </div>

        {/* Project Grid */}
        <div className="grid md:grid-cols-2 gap-4">
          {filtered.map((p, i) => (
            <Link to={`/projects/${p.id}`} key={p.id} className="glass-card p-6 hover-glow group animate-fade-up" style={{ animationDelay: `${i * 0.05}s` }}>
              <div className="flex items-start justify-between mb-3">
                <div>
                  <h3 className="font-sans font-semibold text-foreground group-hover:text-primary transition-colors">{p.title}</h3>
                  <p className="text-xs text-muted-foreground mt-1">{p.clientName}</p>
                </div>
                <span className={`text-[10px] px-2 py-0.5 rounded-full ${p.status === 'open' ? 'bg-primary/20 text-primary' : p.status === 'in_progress' ? 'bg-yellow-500/20 text-yellow-400' : 'bg-green-500/20 text-green-400'}`}>{p.status.replace('_', ' ')}</span>
              </div>
              <p className="text-xs text-muted-foreground line-clamp-2 mb-4">{p.description}</p>
              <div className="flex flex-wrap gap-1.5 mb-4">
                {p.skills.map(s => <span key={s} className="text-[10px] px-2 py-0.5 rounded-full bg-secondary text-muted-foreground">{s}</span>)}
              </div>
              <div className="flex items-center justify-between text-xs text-muted-foreground">
                <span className="flex items-center gap-1"><DollarSign size={12} /> ${p.budget}</span>
                <span className="flex items-center gap-1"><Clock size={12} /> {p.deadline}</span>
                <span>{p.bids.length} bid{p.bids.length !== 1 ? 's' : ''}</span>
              </div>
            </Link>
          ))}
        </div>
        {filtered.length === 0 && (
          <div className="text-center py-20 text-muted-foreground">
            <Filter size={40} className="mx-auto mb-3 opacity-30" />
            <p>No projects match your filters.</p>
          </div>
        )}

        {/* Post Project Modal */}
        {showPost && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 backdrop-blur-sm p-4">
            <div className="glass-card border border-border w-full max-w-lg p-6 animate-fade-up">
              <div className="flex items-center justify-between mb-5">
                <h2 className="font-display text-xl font-bold">Post a Project</h2>
                <button onClick={() => setShowPost(false)} className="text-muted-foreground hover:text-foreground"><X size={18} /></button>
              </div>
              <div className="space-y-4">
                <input value={newProject.title} onChange={e => setNewProject({...newProject, title: e.target.value})} placeholder="Project Title" className="w-full bg-secondary border border-border rounded-lg px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary" />
                <textarea value={newProject.description} onChange={e => setNewProject({...newProject, description: e.target.value})} placeholder="Description" rows={3} className="w-full bg-secondary border border-border rounded-lg px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary resize-none" />
                <div className="grid grid-cols-2 gap-3">
                  <input value={newProject.budget} onChange={e => setNewProject({...newProject, budget: e.target.value})} placeholder="Budget ($)" type="number" className="w-full bg-secondary border border-border rounded-lg px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary" />
                  <input value={newProject.deadline} onChange={e => setNewProject({...newProject, deadline: e.target.value})} type="date" className="w-full bg-secondary border border-border rounded-lg px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary" />
                </div>
                <input value={newProject.skills} onChange={e => setNewProject({...newProject, skills: e.target.value})} placeholder="Skills (comma separated)" className="w-full bg-secondary border border-border rounded-lg px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary" />
                <select value={newProject.category} onChange={e => setNewProject({...newProject, category: e.target.value})} className="w-full bg-secondary border border-border rounded-lg px-4 py-2.5 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary">
                  <option value="">Select Category</option>
                  {categoryOptions.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
                <button onClick={() => setShowPost(false)} className="w-full py-3 rounded-xl gradient-pink text-primary-foreground font-semibold text-sm hover:opacity-90 transition-opacity">Post Project</button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Projects;
