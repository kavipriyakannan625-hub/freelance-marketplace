import React, { createContext, useContext, useState, ReactNode } from 'react';

export type UserRole = 'student' | 'client';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  collegeId?: string;
  company?: string;
  skills?: string[];
  bio?: string;
  avatar?: string;
}

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string, role: UserRole) => void;
  register: (data: Partial<User> & { password: string }) => void;
  logout: () => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const mockStudents: User[] = [
  { id: '1', name: 'Alex Chen', email: 'alex@college.edu', role: 'student', collegeId: 'COL12345', skills: ['React', 'Node.js', 'UI/UX'], bio: 'Full-stack developer passionate about clean design.' },
  { id: '2', name: 'Maya Patel', email: 'maya@college.edu', role: 'student', collegeId: 'COL67890', skills: ['Python', 'Data Science', 'ML'], bio: 'Data science enthusiast with a love for visualization.' },
];

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);

  const login = (email: string, _password: string, role: UserRole) => {
    const mockUser: User = {
      id: Date.now().toString(),
      name: role === 'student' ? 'Alex Chen' : 'TechCorp Inc.',
      email,
      role,
      collegeId: role === 'student' ? 'COL12345' : undefined,
      company: role === 'client' ? 'TechCorp Inc.' : undefined,
      skills: role === 'student' ? ['React', 'Node.js', 'TypeScript'] : undefined,
      bio: role === 'student' ? 'Passionate developer and designer.' : undefined,
    };
    setUser(mockUser);
  };

  const register = (data: Partial<User> & { password: string }) => {
    const newUser: User = {
      id: Date.now().toString(),
      name: data.name || '',
      email: data.email || '',
      role: data.role || 'student',
      collegeId: data.collegeId,
      company: data.company,
      skills: data.skills || [],
      bio: data.bio || '',
    };
    setUser(newUser);
  };

  const logout = () => setUser(null);

  return (
    <AuthContext.Provider value={{ user, login, register, logout, isAuthenticated: !!user }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
};
